#!/usr/bin/python3.6 
import urllib3 
import json 
http = urllib3.PoolManager() 
def lambda_handler(event, context): 
	url = "https://hooks.slack.com/services/xxxxxxx" 
	message = json.loads(event['Records'][0]['Sns']['Message'])
	message_detail = message['detail']
	message_identity = message_detail['userIdentity']
	
	msg_filter = {
		"Usuario": message_identity['type'],
		"Regiao": message_detail['awsRegion'],
		"Evento": message_detail['eventName'],
		"Servico": message_detail['eventSource']
	}
	
	message_dump= json.dumps(msg_filter)
	msg = { 
		"channel": "#Victor Magar", 
		"username": "WEBHOOK_USERNAME", 
		"text": message_dump, 
		"icon_emoji": "" 
	} 
	

	encoded_msg = json.dumps(msg).encode('utf-8') 
	resp = http.request('POST',url, body=encoded_msg) 
	
	print(message_dump)